var posFijo = new Array();

var botones = document.getElementsByTagName('button');
agregaEvento();

function agregaEvento() {
    for (var i = 0; i < botones.length; i++) {
        botones[i].onclick = apila(botones[i])
    }
}

function apila (caracter) {
    console.log(caracter.id)
}